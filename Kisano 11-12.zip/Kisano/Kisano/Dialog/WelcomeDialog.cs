﻿using Kisano.Cards;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Kisano.Dialog
{
    [LuisModel("f905f8a4-fd07-476f-a928-9457aa7a9695", "e31aa77294fc41f4854be4565f609c3c")]
    [Serializable]
    public class WelcomeDialog:LuisDialog<object>
    {
        [LuisIntent("Greeting")]
        public async Task None(IDialogContext context, LuisResult result)
        {
            var message = context.MakeMessage();
            var attachment = LanguageSelection.GetLanguageCard();
            message.Attachments.Add(attachment);
            await context.PostAsync(message);
            context.Wait(MessageReceived);


        }



    }
}