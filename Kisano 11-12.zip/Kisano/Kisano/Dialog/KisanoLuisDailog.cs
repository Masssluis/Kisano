﻿using Kisano.Cards;
using Kisano.Models;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using MicrosoftTranslatorSdk.HttpSamples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Kisano.Dialog
{
    [LuisModel("f905f8a4-fd07-476f-a928-9457aa7a9695", "e31aa77294fc41f4854be4565f609c3c")]
    [Serializable]
    public class KisanoLuisDailog : LuisDialog<object>
    {
        public static string imageTag { get; set; }
        public string UserChoiceOfProduct { get; set; }
        public static string LanguageSelected { get; set; }
        public static Consumer ConsumerDetails { get; set; }
        public static string ProductQuantity { get; set; }
        public const string Entity_Area = "Area";
        public const string Entity_Mandal = "Mandal";
        public const string Entity_District = "District";
        public const string Entity_Language = "Language";
        public const string Entity_weight = "weight";
        [LuisIntent("Greeting")]
        public async Task Greeting(IDialogContext context, LuisResult result)
        {
            //Program.getTranslation();
           
            
            SQLData.MakeConnection(); //make sql connection.
            await context.PostAsync("Type \"Help\" to know more.");
            PromptDialog.Text(context, AdharNumberVerifyAsync,"Please enter your Aadhar Number  \n(example:XXXX-XXXX-XXXX-XXXX)", "Please enter your Aadhar number correctly.", 3);

        }

        [LuisIntent("Language")]
        public async Task Language(IDialogContext context, LuisResult result)
        {
            string language;
            EntityRecommendation title;
            if (result.TryFindEntity(Entity_Language, out title))
            {
                LanguageSelected = title.Entity;

                if (LanguageSelected == "english")
                {
                    SQLData.MakeConnection(); //make sql connection.
                    await context.PostAsync("Type \"Help\" to know more.");
                    PromptDialog.Text(context, AdharNumberVerifyAsync, "Please enter your Aadhar Number  \n(example:XXXX-XXXX-XXXX-XXXX)", "Please enter your Aadhar number correctly.", 3);
                }
                else
                {
                    SQLData.MakeConnection();
                    await context.PostAsync("नमस्ते मैं किसानों हूँ! में आपकी ग्रामीण समस्या को हल करता हूँ ");
                    await context.PostAsync("जदया जानकारी के लिए 'Help' लिखिए");
                    PromptDialog.Text(context, AdharNumberVerifyAsync, "कृपया अपना आधार नंबर दें (उद्धरण के लिए: XXXX-XXXX-XXXX )", "सही आधार नंबर डालें ", 3);

                }

            }


        }

        public async Task AdharNumberVerifyAsync(IDialogContext context, IAwaitable<string> result)
        {
            Consumer consumer = Factory.Factory.getConsumerObj();
            string AadharID = await result;
            ConsumerDetails = consumer.GetConsumerDetails(consumer, AadharID);
            if (ConsumerDetails != null)
            {
                if (LanguageSelected =="english")
                {
                    PromptDialog.Confirm(context, PostAreaConfirmationAsync, $"Hello {ConsumerDetails.Name}, is your current location {ConsumerDetails.Area},{ConsumerDetails.Mandal} ?", "Kindly, confirm your location", 3);
                }
                else
                {

                    PromptDialog.Confirm(context, PostAreaHindiConfirmationAsync, $"नमस्ते  अनिरुद्ध  क्या अप्प धर्माबाद के नागरिक है? ", "कृपया अपना गांव तय केजीए", 3);
                }
            }
            else
            {
                PromptDialog.Text(context, AdharNumberVerifyAsync, "Kindly, provide correct Aadhar Number.", "Provide correct aadhar number", 2);

            }

        }

        public async Task PostAreaHindiConfirmationAsync(IDialogContext context, IAwaitable<bool> result)
        {
            var message = context.MakeMessage();
            var confirm = await result;

            if (confirm)
            {
                var attachment = MainCategoryCard.GetMainCategoryCard();
                message.Attachments.Add(attachment);
                context.Wait(MessageReceived);
            }
            else
            {
                await context.PostAsync("कृपया अपना गांव का नाम , तालुका और जिला भेजे. \n (उद्धरण के लिए: गांव का नाम,तालुका,जिला भेजे)");
                context.Wait(MessageReceived);
            }
        }

        public async Task PostAreaConfirmationAsync(IDialogContext context, IAwaitable<bool> result)
        {
            var message = context.MakeMessage();
            var confirm = await result;
           
            if (confirm)
            {
                var attachment = MainCategoryCard.GetMainCategoryCard();
                message.Attachments.Add(attachment);
                await context.PostAsync(message);
                context.Wait(MessageReceived);
            }
            else
            {
                await context.PostAsync("Please provide your Area, Mandal and District. \n(for example alwal, Malkajgiri, Hyderabad)");
            }

        }

        [LuisIntent("NewAddress")]
        public async Task NewAddress(IDialogContext context, LuisResult result)
        {
            var message = context.MakeMessage();
            EntityRecommendation title;
            if (result.TryFindEntity(Entity_Area, out title))
            {
                ConsumerDetails.Area = title.Entity;
            }
            if (result.TryFindEntity(Entity_Mandal, out title))
            {
                ConsumerDetails.Mandal = title.Entity;
            }
            if (result.TryFindEntity(Entity_District, out title))
            {
                ConsumerDetails.District = title.Entity;
            }

            await context.PostAsync("Your order has been placed!");
            // wait for few sec and show first card with logout!
            var attachment = OrderPlacedCard.GetOrderCofirmationCard();
            message.Attachments.Add(attachment);
            await context.PostAsync(message);
            context.Wait(MessageReceived);


        }
        [LuisIntent("Soil Button")]
        public async Task SoilTest(IDialogContext context, LuisResult result)
        {
            var message = context.MakeMessage();
            var attachment = SoilRequestCard.GetSoilRequest();
            message.Attachments.Add(attachment);
            await context.PostAsync(message);
            context.Wait(MessageReceived);

        }
        [LuisIntent("NewSoilRequest")]
        public async Task NewSoilRequest(IDialogContext context, LuisResult result)
        {
            PromptDialog.Confirm(context,RaiseRequestAsync, $"Do you wish to rise a request for soil test for address:{ConsumerDetails.Area},{ConsumerDetails.Mandal},{ConsumerDetails.District}?", "Do you want to raise a new request?",3,PromptStyle.Auto);

        }

        public async Task RaiseRequestAsync(IDialogContext context,IAwaitable<bool> result)
        {
            
            var confirm = await result;
            if (confirm)
            {

                Random rnd = new Random();
                string number = "INC16645";
                OutLookMail.SendMailDetails(number, ConsumerDetails);
                await context.PostAsync($"Done! your request has been raised.An Excecutive from Your Mandal:{ConsumerDetails.Mandal} will connect with you in one working day to collect the soil samples.");
                await context.PostAsync($"Your ID for reference is:{number}");
                System.Threading.Thread.Sleep(4500);
                PromptDialog.Confirm(context, PostRequestAsync, "Great! anything else I may help you with?", "Do you wish to do somthing more?", 3, PromptStyle.Auto);
              
            }
            else
            {
                PromptDialog.Text(context,GetCurrentAddressAsync, "Kindly, provide your currect address.", "Please send me your current address", 2);

            }
          
        }

        public async Task PostRequestAsync(IDialogContext context, IAwaitable<bool> result)
        {
            var message = context.MakeMessage();
            var confirm = await result;
            if (confirm)
            {
                var attachment = MainCategoryCard.GetMainCategoryCard();
                message.Attachments.Add(attachment);
                await context.PostAsync(message);
                context.Wait(MessageReceived);

            }
       else {

                await context.PostAsync("If you wish to Logout please send 'Logout'.");
                context.Wait(MessageReceived);
            }
        }

        public async Task GetCurrentAddressAsync(IDialogContext context, IAwaitable<string> result)
        {
            var address = await result;
            Random rnd = new Random();
            string number = "INC16645";
            OutLookMail.SendMailDetails(number, ConsumerDetails);
            await context.PostAsync($"Done! your request has been raised.An Excecutive from Your Mandal:{ConsumerDetails.Mandal} will connect with you in one working day to collect the soil samples.");
            await context.PostAsync($"Your ID for reference is:{number}");
            System.Threading.Thread.Sleep(4500);
            PromptDialog.Confirm(context, PostRequestAsync, "Great! anything else I may help you with?", "Do you wish to do somthing more?", 3, PromptStyle.Auto);

        }

        [LuisIntent("TestResults")]
        public async Task SoilTestResult(IDialogContext context, LuisResult result)
        {
            Consumer consumer = new Consumer();
            List<string> options = new List<string>();
            options.Add("Picture");
            options.Add("Manually");
            PromptDialog.Choice(context,CheckForSoilRequestStatusAsync,options , "Select any of the options below to enter Reference ID", "Please select an any one of the options below",2,PromptStyle.Auto);
            


        }
        public async Task CheckForSoilRequestStatusAsync(IDialogContext context,IAwaitable<string> result)
        {
            var userChoice = await result;
            switch (userChoice)
            {
                case "Picture":
               
                    PromptDialog.Attachment(context,ImageValidateAsync,"Send me a picture containing Reference ID \n(Reference ID is in the format of INXXXXX)", contentTypes: null, retry: "Please try sending again.", attempts: 2);
                   
                    break;

                case "Manually":

                    PromptDialog.Text(context, ConfirmManualRequestIDAsync, "Please enter the reference ID", "Please enter reference ID correctly", 2);
                    break;

            }


        }
        public async Task ConfirmManualRequestIDAsync(IDialogContext context, IAwaitable<string> result)
        {
            var message = context.MakeMessage();
            var crouselMessage = context.MakeMessage();
            ConsumerDetails.RequestID = await result;
            Consumer consumer = new Consumer();
            ConsumerDetails = consumer.GetConsumerDataPostRequest(consumer,ConsumerDetails.RequestID);

            var attachment = SoilRequestRecieptCard.GetRecipientCard(ConsumerDetails);
            message.Attachments.Add(attachment);
            await context.PostAsync(message);

            var attachments = StoreCrousel.GetStoreCrousel();
            foreach (var imageattachment in attachments)
            {
                crouselMessage.Attachments.Add(imageattachment);
            }
            crouselMessage.AttachmentLayout = AttachmentLayoutTypes.Carousel;
            await context.PostAsync(crouselMessage);
            context.Wait(MessageReceived);
        }

        public async Task ImageValidateAsync(IDialogContext context,IAwaitable<IEnumerable<Attachment>> result)
        {
            
                Activity OCRActivity = await OCRIdentitfier.demo(RefractorManager.Activity);
                ConsumerDetails.RequestID = OCRActivity.Text;
                Consumer consumer = new Consumer();
                ConsumerDetails = consumer.GetConsumerDataPostRequest(consumer, OCRActivity.Text);
                PromptDialog.Confirm(context, this.ConfirmOCRRequestIDAsync, $"Your Reference ID is {OCRActivity.Text}.Kindly, confirm your Reference ID.", "Please confirm your RequestID", 3, PromptStyle.Auto);
           

        }

        public async Task ConfirmOCRRequestIDAsync(IDialogContext context, IAwaitable<bool> result)
        {
            var message = context.MakeMessage();
            var crouselMessage = context.MakeMessage();
            var confirm = await result;
            
            if (confirm)
            {
                var attachment = SoilRequestRecieptCard.GetRecipientCard(ConsumerDetails);
                message.Attachments.Add(attachment);
                await context.PostAsync(message);

                var attachments = StoreCrousel.GetStoreCrousel();
                foreach (var imageattachment in attachments)
                {
                    crouselMessage.Attachments.Add(imageattachment);
                }
                crouselMessage.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                await context.PostAsync(crouselMessage);
                context.Wait(MessageReceived);
            }
            else
            {

                PromptDialog.Attachment(context, ImageValidateAsync, "Send me a picture containing Reference ID \n(Reference ID is in the format of INXXXXX)", contentTypes: null, retry: "Please try sending again.", attempts: 2);
            }


        }

        [LuisIntent("Buy Now")]
        public async Task BuyNowAsync(IDialogContext context, LuisResult result)
        {
            var message = context.MakeMessage();
            var attachment = QuantityCard.GetQuantity();
            message.Attachments.Add(attachment);
            await context.PostAsync(message);
            context.Wait(MessageReceived);
        }

        [LuisIntent("ProductQuantity")]
        public async Task GetProductQuantityAsync(IDialogContext context, LuisResult result)
        {
            EntityRecommendation title;
            if (result.TryFindEntity(Entity_weight, out title))
            {
               ProductQuantity = title.Entity;
            }
           
            PromptDialog.Confirm(context, PlaceOrderAsync, $"Do you wish to ship to this address {ConsumerDetails.Area + " " + ConsumerDetails.Mandal + " " + ConsumerDetails.District}?", "Please confirm your address", 3, PromptStyle.Auto);

        }

        public async Task PlaceOrderAsync(IDialogContext context, IAwaitable<bool> result)
        {
            var message = context.MakeMessage();
            var confirm = await result;
            if (confirm)
            {
                await context.PostAsync("Your order has been placed!");
                // wait for few sec and show first card with logout!
                var attachment = OrderPlacedCard.GetOrderCofirmationCard();
                message.Attachments.Add(attachment);
                PromptDialog.Confirm(context, PostRequestAsync, "Great! anything else I may help you with?", "Do you wish to do somthing more?", 3, PromptStyle.Auto);

            }
            else
            {
                //change address request
                await context.PostAsync("Please provide your address in the form of Area,Mandal,District");
                context.Wait(MessageReceived);
            }
        }

        [LuisIntent("AgroStores")]

        public async Task ChooseProductType(IDialogContext context, LuisResult result)
        {
            Consumer consumer = new Consumer();
            List<string> options = new List<string>();
            options.Add("Seeds");
            options.Add("Pesticides");
            PromptDialog.Choice(context, CheckimageDescriptionAsync, options, "Select a Product Type:", "Please select an any one of the options below", 2, PromptStyle.Auto);
            

        }

        public async Task CheckimageDescriptionAsync(IDialogContext context, IAwaitable<string> result)
        {
            UserChoiceOfProduct = await result;
            Consumer consumer = new Consumer();
            List<string> options = new List<string>();
            options.Add("Picture");
            options.Add("Manually");
            PromptDialog.Choice(context, CheckForDescribeImageAsync, options, "Select any of the options below to enter crop type", "Please select an any one of the options below", 2, PromptStyle.Auto);

        }


        public async Task CheckForDescribeImageAsync(IDialogContext context, IAwaitable<string> result)
        {
            var userChoice = await result;
            switch (userChoice)
            {
                case "Picture":

                    PromptDialog.Attachment(context, ImageDescribeAsync, "Send me a picture containing Crop image)", contentTypes: null, retry: "Please try sending again.", attempts: 2);

                    break;

                case "Manually":

                    PromptDialog.Text(context, ConfirmManualCropNameAsync, "Please enter the crop name", "Please enter reference ID correctly", 2);
                    break;

            }
        }

        public async Task ConfirmManualCropNameAsync(IDialogContext context, IAwaitable<string> result)
        {
            var cropName = await result;
            imageTag = cropName;

            if (UserChoiceOfProduct == "Seeds")
            {
                //cards for seeds
                var message = context.MakeMessage();
                var crouselMessage = context.MakeMessage();
                await context.PostAsync($"seeds recommended for {imageTag} :");

                var attachments = BuySeedCard.GetSeedsCrousel();
                foreach (var imageattachment in attachments)
                {
                    crouselMessage.Attachments.Add(imageattachment);
                }
                crouselMessage.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                await context.PostAsync(crouselMessage);
                context.Wait(MessageReceived);

            }
            else if (UserChoiceOfProduct == "Pesticides")
            {
                //cards for pesticides
                var message = context.MakeMessage();
                var crouselMessage = context.MakeMessage();
                await context.PostAsync($"Pesticides recommended for {imageTag} :");


                var attachments = BuyPesticidesCrousel.GetPesticidesCrousel();
                foreach (var imageattachment in attachments)
                {
                    crouselMessage.Attachments.Add(imageattachment);
                }
                crouselMessage.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                await context.PostAsync(crouselMessage);
                context.Wait(MessageReceived);
            }
        }


        public async Task ImageDescribeAsync(IDialogContext context, IAwaitable<IEnumerable<Attachment>> result)
        {

            // call image describe class here and a confirm prompt for confirming
           
            Activity DescribeimageActivity = await DescribeImageCogSer.demo(RefractorManager.Activity);
            imageTag = DescribeimageActivity.Text;
            PromptDialog.Confirm(context, this.ConfirmImageDescribeAsync, $"Your crop is {imageTag}.Please confirm!", "Please confirm your RequestID", 3, PromptStyle.Auto);

        }

        public async Task ConfirmImageDescribeAsync(IDialogContext context, IAwaitable<bool> result)
        {

            var confirm = await result;

            if (confirm)
            {
                //if confirm provide seeds or fertilizers menu to the user according to the product choice he made , that product choice is saved in a property above.
                if (UserChoiceOfProduct == "Seeds")
                {
                    //cards for seeds
                    var message = context.MakeMessage();
                    var crouselMessage = context.MakeMessage();
                    await context.PostAsync($"seeds recommended for {imageTag} :");

                    var attachments = BuySeedCard.GetSeedsCrousel();
                    foreach (var imageattachment in attachments)
                    {
                        crouselMessage.Attachments.Add(imageattachment);
                    }
                    crouselMessage.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                    await context.PostAsync(crouselMessage);
                    context.Wait(MessageReceived);

                }
                else if (UserChoiceOfProduct == "Pesticides")
                {
                    //cards for pesticides
                    var message = context.MakeMessage();
                    var crouselMessage = context.MakeMessage();
                    await context.PostAsync($"Pesticides recommended for {imageTag} :");


                    var attachments = BuyPesticidesCrousel.GetPesticidesCrousel();
                    foreach (var imageattachment in attachments)
                    {
                        crouselMessage.Attachments.Add(imageattachment);
                    }
                    crouselMessage.AttachmentLayout = AttachmentLayoutTypes.Carousel;
                    await context.PostAsync(crouselMessage);
                    context.Wait(MessageReceived);
                }

            }
            else
            {
                PromptDialog.Text(context, ConfirmManualCropNameAsync, "Please enter the crop name", "Please enter reference ID correctly", 2);

            }
        }


        [LuisIntent("Help")]
        public async Task Help(IDialogContext context, LuisResult result)
        {

            if (LanguageSelected == "english")
            {
                await context.PostAsync("Type Soil Test to raise soil test request or to view previous test results.");
                await context.PostAsync("Type Agro Store To Buy Seeds and Pesticides as per your crops and get is delivers at your door steps");
                await context.PostAsync("Go to quick suggestions to get weather forecasts for your area.");

            }
            else
            {

                await context.PostAsync("मिट्टी परीक्षण अनुरोध या पिछले परिणाम परीक्षण के लिए मिट्टी परीक्षण लिखें।");
                await context.PostAsync("बीज और कीटनाशकों खरीदने के लिए के Agro Store लिखें");
                await context.PostAsync("अपने क्षेत्र के लिए मौसम के पूर्वानुमान प्राप्त करने के लिए त्वरित सुझाव लिखें");
            }

            context.Wait(MessageReceived);


        }

        [LuisIntent("Logout")]
        public async Task Logout(IDialogContext contexet, LuisResult result)
        {



        }
    }
}