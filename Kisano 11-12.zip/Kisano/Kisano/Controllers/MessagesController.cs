﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Internals;
using Autofac;
using System.Diagnostics;
using Kisano.Dialog;
using Kisano.Cards;
using Kisano.Models;

namespace Kisano
{
    [BotAuthentication]
    public class MessagesController : ApiController
    {
        /// <summary>
        /// POST: api/Messages
        /// Receive a message from a user and reply to it
        /// </summary>
        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
           
            if (activity != null)
            {
                RefractorManager.Connector = new ConnectorClient(new Uri(activity.ServiceUrl));
                // one of these will have an interface and process it
                switch (activity.GetActivityType())
                {
                 
               
                    case ActivityTypes.Message:

                        RefractorManager.Activity = activity;
                   
                        //We start with the root dialog
                        await Conversation.SendAsync(activity, () => new KisanoLuisDailog());


                        break;

                    case ActivityTypes.ConversationUpdate:
                        IConversationUpdateActivity update = activity;
                        using (var scope = DialogModule.BeginLifetimeScope(Conversation.Container, activity))
                        {

                            var client = scope.Resolve<IConnectorClient>();
                            if (update.MembersAdded.Any())
                            {
                                var reply = activity.CreateReply();
                                foreach (var newMember in update.MembersAdded)
                                {
                                    if (newMember.Id != activity.Recipient.Id)
                                    {
                                        activity.Text = "hello";
                                        await Conversation.SendAsync(activity, () => new WelcomeDialog());
                                        // var attachment = LanguageSelection.GetLanguageCard(activity);
                                        //  message.Attachments.Add(attachment);
                                    }
                                    else
                                    {
                                        activity.Text = "hello";
                                        await Conversation.SendAsync(activity, () => new WelcomeDialog());
                                        // var attachment = LanguageSelection.GetLanguageCard(activity);
                                        // message.Attachments.Add(attachment);
                                    }

                                }
                            }
                            break;
                        }
                    case ActivityTypes.ContactRelationUpdate:
                    case ActivityTypes.Typing:
                    case ActivityTypes.DeleteUserData:
                    case ActivityTypes.Ping:
                    default:
                        Trace.TraceError($"Unknown activity type ignored: {activity.GetActivityType()}");
                        break;
                }
            }
            return new HttpResponseMessage(System.Net.HttpStatusCode.Accepted);

        }
    }
}
