﻿using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kisano.Cards
{
    public class QuantityCard
    {
        public static Attachment GetQuantity()
        {

            List<CardAction> buttons = new List<CardAction>();
            List<string> soilOptions = new List<string>();
            soilOptions.Add("500 gms");
            soilOptions.Add("1.0 kg");
            soilOptions.Add("2.0 kg");
            soilOptions.Add("2.5 kg");

            foreach (var soilOption in soilOptions)
            {
                CardAction button = new CardAction()
                {
                    Title = soilOption,
                    Type = "imBack",
                    Value= soilOption
                };
                buttons.Add(button);
            }


            HeroCard SoilRequestcard = new HeroCard()
            {
                Subtitle = "Select quantity",
                Buttons = buttons,

            };

            Attachment attachment = SoilRequestcard.ToAttachment();
            return attachment;

        }

    }
}