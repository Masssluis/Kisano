﻿using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kisano.Cards
{
    public class SoilRequestCard
    {
        public static Attachment GetSoilRequest()
        {

            List<CardAction> buttons = new List<CardAction>();
            List<string> soilOptions = new List<string>();
            soilOptions.Add("New Request");
            soilOptions.Add("Soil Report");

            foreach (var soilOption in soilOptions)
            {
                CardAction button = new CardAction()
                {
                    Title = soilOption,
                    Type = "imBack",
                    Value=soilOption

                };
                buttons.Add(button);
            }


            HeroCard SoilRequestcard = new HeroCard()
            {
                Subtitle = "Choose an option below to get started:",
                Buttons = buttons,

            };

            Attachment attachment = SoilRequestcard.ToAttachment();
            return attachment;

        }
    }
}