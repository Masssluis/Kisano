﻿using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Kisano.Dialog;

namespace Kisano.Cards
{
    public class OrderPlacedCard
    {

        public static Attachment GetOrderCofirmationCard()
        {
            DateTime dateTime = new DateTime();

            Dictionary<string, string> attributes = new Dictionary<string, string>();
            attributes.Add("Order ID:","AX787783");
            attributes.Add("Date:", DateTime.Today.ToString("dd/MMyyyy"));
            attributes.Add("Tracking ID", "TY28342983493");
            attributes.Add("Courier", "Armax");
            attributes.Add("Quatity", KisanoLuisDailog.ProductQuantity);
            attributes.Add("Price", "INR 560");
            attributes.Add("PaymentType", "cash on delivery");
            attributes.Add("Expected Delivery Date", DateTime.Now.AddDays(2).ToString("dd/MM/yyyy"));
            attributes.Add("Shipping Address:", $"{KisanoLuisDailog.ConsumerDetails.Area},{KisanoLuisDailog.ConsumerDetails.Mandal},{ KisanoLuisDailog.ConsumerDetails.District}");
        

            List<ReceiptItem> items = new List<ReceiptItem>();

            foreach (var attribute in attributes)

            {

                ReceiptItem item = new ReceiptItem()
                {
                    Title = attribute.Key,
                    Price = attribute.Value,               
                 
                };

                items.Add(item);

            }

            ReceiptCard plCard = new ReceiptCard()
            {
                Title = "Order Details",
                Items = items,
              
            };
            Attachment attachment = plCard.ToAttachment();
            return attachment;
        }
    }
}