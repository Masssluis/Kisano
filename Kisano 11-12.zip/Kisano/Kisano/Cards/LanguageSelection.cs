﻿using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kisano.Cards
{
    public class LanguageSelection
    {
        public static Attachment GetLanguageCard()
        {
            
            List<string> Options = new List<string>();
            Options.Add("हिंदी");
            Options.Add("English");
        
            List<CardAction> buttons = new List<CardAction>();

            foreach (var option in Options)
            {
                CardAction button = new CardAction()
                {
                    Type = "imBack",
                    Title= option,
                    Value= option
                  
                };
                buttons.Add(button);
            }

            HeroCard card = new HeroCard()
            {

                Buttons = buttons,
                Subtitle = "Hi, I am Kisano an agriculture oriented bot.\n Choose a language below..",
                

            };

            Attachment attachment = card.ToAttachment();
            return attachment;
        }

    }
}