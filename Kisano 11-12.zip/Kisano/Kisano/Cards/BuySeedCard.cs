﻿using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kisano.Cards
{
    public class BuySeedCard
    {

        public static List<Attachment> GetSeedsCrousel()
        {
            List<Attachment> attachment = new List<Attachment>();



            Dictionary<string, string> cardContentList = new Dictionary<string, string>();

            cardContentList.Add("Suitable for brocolli", "https://www.spicherandco.com/images/P/68231%20BC%20Broccoli%20Seed%20Packet.jpg");
            cardContentList.Add("recommended for brocolli", "http://www.hillfootgardencentre.co.uk/files/images/webshop/broccoli-early-purple-sprouting-1-packet-of-seeds-vegetables_n.jpg");

            List<CardAction> buttons = new List<CardAction>();

            CardAction button = new CardAction()
            {
                Title = "Buy Now",
                Type = "imBack",
                Value="Buy Now"

            };

            buttons.Add(button);


            List<CardImage> images = new List<CardImage>();

            foreach (KeyValuePair<string, string> cardContent in cardContentList)
            {
                List<CardImage> cardImages = new List<CardImage>();
                cardImages.Add(new CardImage(url: cardContent.Value));
                var item = cardContent.Key;

                HeroCard card = new HeroCard
                {
                    Subtitle = item,
                    Images = cardImages,
                    Buttons = buttons

                };
                attachment.Add(card.ToAttachment());
            }
            return attachment;
        }

    }
}