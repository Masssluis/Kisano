﻿using Kisano.Models;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kisano.Cards
{
    public class SoilRequestRecieptCard
    {

        public static Attachment GetRecipientCard(Consumer consumer)
        {
            DateTime dateTime = new DateTime();
           
            Dictionary<string,string> attributes = new Dictionary<string,string>();
            attributes.Add("Report ID:",consumer.RequestID);
            attributes.Add("Date:",DateTime.Today.ToString("dd/MMyyyy"));
            attributes.Add("Season:","Rabi");
            attributes.Add("Area:", $"{consumer.Area},{consumer.Mandal},{consumer.District}");
            attributes.Add("Soil Type:","Red Soil");
            attributes.Add("Soil Toxicity:", "Salanity Medium");
            attributes.Add("Moisture Content:", "Normal" );
            attributes.Add("Suggested Crops:", "Groundnut, Sunflower, Rice, Cotton, Maize, Chillies");
            attributes.Add("Recommended Fertilizers:","Nitrogen(GroundNut,SunFlower),Rotted Manure(Chillies)");
            attributes.Add("Report Valid Till:","15/02/2017");

            List<ReceiptItem> items = new List<ReceiptItem>();
  
            foreach (var attribute in attributes)

            {

                ReceiptItem item = new ReceiptItem()
                {
                    Title = attribute.Key,
                    Price = attribute.Value

                };

                items.Add(item);

            }

            ReceiptCard plCard = new ReceiptCard()
            {
                Title = "Soil Report",
                Items =  items,
               
            };
            Attachment attachment = plCard.ToAttachment();
            return attachment;
        }
    }
}