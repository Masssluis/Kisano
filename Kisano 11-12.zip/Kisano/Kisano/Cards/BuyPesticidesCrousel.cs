﻿using Kisano.Dialog;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kisano.Cards
{
    public class BuyPesticidesCrousel
    {

        public static List<Attachment> GetPesticidesCrousel()
        {
            List<Attachment> attachment = new List<Attachment>();



            Dictionary<string, string> cardContentList = new Dictionary<string, string>();

            cardContentList.Add($"Suitable for crop {KisanoLuisDailog.imageTag}", "http://pestkill.org/wp-content/uploads/neem-oil-extract.jpg");
            cardContentList.Add($"Recommended for crop {KisanoLuisDailog.imageTag}", "http://www.discoverneem.com/images/xtheraneem-neem-oil-for-the-garden.jpg.pagespeed.ic.T58PmJC2yo.jpg");
            cardContentList.Add($"Trending option for crop {KisanoLuisDailog.imageTag}", "http://www.supplementsaddict.com/m/images_us/garden-safe-neem-oil-extract-concentrate.jpg");
            List<CardAction> buttons = new List<CardAction>();

            CardAction button = new CardAction()
            {
                Title = "Buy Now",
                Type = "imBack",
                Value="Buy Now"
            };

            buttons.Add(button);


            List<CardImage> images = new List<CardImage>();

            foreach (KeyValuePair<string, string> cardContent in cardContentList)
            {
                List<CardImage> cardImages = new List<CardImage>();
                cardImages.Add(new CardImage(url: cardContent.Value));
                var item = cardContent.Key;

                HeroCard card = new HeroCard
                {
                    Subtitle = item,
                    Images = cardImages,
                    Buttons = buttons

                };
                attachment.Add(card.ToAttachment());
            }
            return attachment;
        }

    }
}