﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace Kisano.Models
{
    public class OutLookMail
    {
        private const string SmtpServer = "smtp.live.com";
        private const int SmtpPort = 587;
        private const string FromAddress = "Masss_Luis@outlook.com";
        private const string Password = "Masss12345";
        public static string EmailID { get; set; }

        public static void SendMailDetails(string ticketId,Consumer consumer)
        {
            EmailID = "manish_chitre@outlook.com";
            string subject = $"Soil Request Registerd for {consumer.Name} from {consumer.Area},{consumer.Mandal}";
            string body = $"Dear Excecutive, A Request has been raised by {consumer.Name} from  {consumer.Area},{consumer.Mandal},{consumer.District}.The Request Resolution time is 1 working Day.  \n Request ID:{ticketId} \n\n";
            SendMail(EmailID, subject, body);
        }

        public static void SendMail(string toAddress, string subject, string body)
        {
            var client = new SmtpClient(SmtpServer, SmtpPort)
            {
                Credentials = new NetworkCredential(FromAddress, Password),
                EnableSsl = true
            };
            client.Send(FromAddress, toAddress, subject, body);
        }
    }
}