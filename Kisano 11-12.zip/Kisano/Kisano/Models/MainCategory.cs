﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kisano.Models
{
    public class MainCategory
    {
       


        public static List<string> GetMainCategoryList()
        {
            List<string> categoryList = new List<string>();

            categoryList.Add("Soil Test");
            categoryList.Add("Agro Store");
            categoryList.Add("Quick Suggestions");
            categoryList.Add("General Query");
            categoryList.Add("Logout");

            return categoryList;
        }



        public static List<string> GetMainHindiCategoryList()
        {
            List<string> categoryList = new List<string>();
            categoryList.Add("मीटी के जाँच");
            categoryList.Add("ऑनलइन स्टोर(English)");
            //  mainCategory.CategoryItems.Add("Quick Suggestions");
            categoryList.Add("सामान्य पूछताछ");
            categoryList.Add("लॉगआउट");

            return categoryList;
        }
    }
}