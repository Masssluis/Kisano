﻿using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kisano.Models
{
    public class RefractorManager
    {
        public static Activity Activity { get; set; }
        public static ConnectorClient Connector { get; set; }
    }
}