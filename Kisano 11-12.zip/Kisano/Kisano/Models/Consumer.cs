﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Numerics;

namespace Kisano.Models
{
    public class Consumer
    {
        public  string AadharID { get; set; }
        public  string Name { get; set; }
        public  string Age { get; set; }
        public  string Area { get; set; }
        public  string Mandal { get; set; }
        public  string District { get; set; }
        public  string Contact_Number { get; set; }
        public  string RequestID { get; set; }
        public Consumer GetConsumerDetails(Consumer consumer,string AadharID)
        {
            var reader = SQLData.ConsumerDetailsDB(AadharID, SQLData.SQLConnection);

            while (reader.Read())
            {
               
                consumer.AadharID = AadharID;
                consumer.Name = reader["Name"].ToString();
                consumer.Age = reader["Age"].ToString();
                consumer.Area = reader["Area"].ToString();
                consumer.Mandal = reader["Mandal"].ToString();
                consumer.District = reader["District"].ToString();
                consumer.Contact_Number = reader["Contact_Number"].ToString();               
            }
            return consumer;
        }

        public Consumer GetConsumerDataPostRequest(Consumer consumer, string requestID)
        {

            var reader = SQLData.VerifyRequestID(requestID, SQLData.SQLConnection);

            while (reader.Read())
            {
                consumer.AadharID = "111111111111";
                consumer.Name = reader["Name"].ToString();
                consumer.Age = reader["Age"].ToString();
                consumer.Area = reader["Area"].ToString();
                consumer.Mandal = reader["Mandal"].ToString();
                consumer.District = reader["District"].ToString();
                consumer.Contact_Number = reader["Contact_Number"].ToString();
                consumer.RequestID = "INC16645";
            }
            return consumer;
        }
    }
}