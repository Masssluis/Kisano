﻿using Kisano.Utility;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Kisano.Models
{
    public class SQLData
    {

        public static SqlConnection SQLConnection { get; set; }
        public const string Get_Consumer_Details = "select Name,Age,Area,Mandal,District,Contact_Number from Aadhar where Aadhar_Number=@Adhar_ID";
        public const string Get_Info_By_Request_ID = "select Name,Age,Area,Mandal,District,Contact_Number from Aadhar where Request_ID=@Request_ID";
        public static void MakeConnection()
        {

            SQLConnection = DbUtility.GetSQLConnectionObj();

        }

        public static SqlDataReader ConsumerDetailsDB(string AadharID,SqlConnection connection)
        {
            var command = new SqlCommand(Get_Consumer_Details, connection);
           
            command.Parameters.AddWithValue("@Adhar_ID", AadharID);

            var reader = command.ExecuteReader();
             
             
            return reader;
                
            
        }

        public static SqlDataReader VerifyRequestID(string requestID, SqlConnection connection)
        {
            var command = new SqlCommand(Get_Info_By_Request_ID, connection);
            
            command.Parameters.AddWithValue("@Request_ID", requestID);

            var reader = command.ExecuteReader();
                
            return reader;
            
        }    
    }
}