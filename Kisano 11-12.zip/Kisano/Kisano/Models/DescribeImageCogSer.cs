﻿using Kisano.Utility;
using Microsoft.Bot.Connector;
using Microsoft.IdentityModel.Protocols;
using Microsoft.ProjectOxford.Vision;
using Microsoft.ProjectOxford.Vision.Contract;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace Kisano.Models
{
    public class DescribeImageCogSer
    {

        public static async Task<Activity> demo(Activity activity)
        {
            Activity reply = activity.CreateReply("Your message contains no images, please try attaching an image file.");
            bool imageFound = false;
            // calculate something for us to return
            int length = (activity.Text ?? string.Empty).Length;
            AnalysisResult res = null;

            if (activity?.Attachments?.Count() > 0)
            {
                var attachment = activity.Attachments.First();
                //if (attachment.ContentType == "image")

                if (attachment.ContentType.Contains("image"))
                {
                    var token = await OCRTokenUtility.GetBearerToken();
                    var client = new HttpClient();
                    client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer " + token);
                    var image = await client.GetStreamAsync(attachment.ContentUrl);
                    var visionClient = new VisionServiceClient(ConfigurationManager.AppSettings["VisionKey"]);
                    try
                    {
                        res = await visionClient.DescribeAsync(image);
                        // return our reply to the user                    
                        reply = activity.CreateReply(res.Description.Tags[0]);
                        return reply;
                        imageFound = true;
                    }
                    catch
                    {
                        reply = activity.CreateReply($"Some error occured ,this may because of a large or small file size");
                        return reply;
                    }
                }
            }

            if (!imageFound)
            {
                return reply;
            }
            return null;
        }

    }
}